package practical;

import java.util.Scanner;

public class Practical1ArithmeticOperators {

    public static void main(String[] args) {
        maxNumberFinder();
    }

    //Ex.1
    //Напишіть програму для обчислення виразу a + b * c / d, де a, b, c і d - цілі числа, які користувач вводить з клавіатури.
    private static void calculate() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a: ");
        int a = sc.nextInt();
        System.out.println("Enter b: ");
        int b = sc.nextInt();
        System.out.println("Enter c: ");
        int c = sc.nextInt();
        System.out.println("Enter d: ");
        int d = sc.nextInt();
        double result = a + (double) (b * c) / d;
        System.out.println("Result : " + result);
    }

    //Ex.2
    //Напишіть програму, яка перевіряє, чи є введене користувачем число парним чи непарним.
    private static void evenOddChecker () {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number: ");
        int num = sc.nextInt();

        if( num % 2 == 0) {
            System.out.println(num + " is pair");
        }
        else
        {
            System.out.println(num + " is not pair");
        }
    }

    //Ex.3
    //Напишіть програму для обчислення площі прямокутника за його довжиною та шириною, які користувач вводить з клавіатури.
    private static void rectangleAreaCalculator () {
        Scanner sc = new Scanner(System.in);

        System.out.println("Input weight: ");
        int weight = sc.nextInt();
        System.out.println("Input height: ");
        int height = sc.nextInt();

        int s = height * weight;

        System.out.println("S = " + s);

    }

    //Ex.4
    //Напишіть програму, яка перевіряє, чи особа, введена користувачем, досягла повноліття (18 років та старше).
    private static void ageChecker () {

        Scanner sc = new Scanner(System.in);
        System.out.println("Input age: ");

        int age = sc.nextInt();

        if(age > 18)
        {
            System.out.println("Itis ok");
        }

        else {
            System.out.println("Wait");
        }
    }

    private static void maxNumberFinder () {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Input 1st");
        int num1 = scanner.nextInt();
        System.out.println("Input 2nd");
        int num2 = scanner.nextInt();
        System.out.println("Input 3rd");
        int num3 = scanner.nextInt();


        int maxNum = Math.max(Math.max(num1, num2), num3);

        System.out.println(maxNum);


    }

}
