package lessons;

public class SeondLessonJava {

    public static void main(String[]args){

        int age = 20;


        if(age > 18){
            System.out.println("Yes you can get drive license ");

        }

        else{
            System.out.println("No, you are too yong");
        }


    }
}